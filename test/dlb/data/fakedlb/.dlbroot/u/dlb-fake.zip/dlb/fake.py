def inform():
    print('successfully completed.')
